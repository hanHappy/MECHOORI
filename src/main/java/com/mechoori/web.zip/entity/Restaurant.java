package com.mechoori.web.entity;

public class Restaurant {
	private int id;
	private int foodTypeId;
	private String name;
	private String intro;
	private String address;
	private String operatingTime;
	private String contactNumber;
	private int likedCount;
	private int ratedCount;

	public Restaurant() {
		// TODO Auto-generated constructor stub
	}

	public Restaurant(int id, int foodTypeId, String name, String intro, String address, String operatingTime,
			String contactNumber, int likedCount, int ratedCount) {
		this.id = id;
		this.foodTypeId = foodTypeId;
		this.name = name;
		this.intro = intro;
		this.address = address;
		this.operatingTime = operatingTime;
		this.contactNumber = contactNumber;
		this.likedCount = likedCount;
		this.ratedCount = ratedCount;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getFoodTypeId() {
		return foodTypeId;
	}

	public void setFoodTypeId(int foodTypeId) {
		this.foodTypeId = foodTypeId;
	}

	public String getIntro() {
		return intro;
	}

	public void setIntro(String intro) {
		this.intro = intro;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getOperatingTime() {
		return operatingTime;
	}

	public void setOperatingTime(String operatingTime) {
		this.operatingTime = operatingTime;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public int getLikedCount() {
		return likedCount;
	}

	public void setLikedCount(int likedCount) {
		this.likedCount = likedCount;
	}

	public int getRatedCount() {
		return ratedCount;
	}

	public void setRatedCount(int ratedCount) {
		this.ratedCount = ratedCount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
