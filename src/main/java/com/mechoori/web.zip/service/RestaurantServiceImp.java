package com.mechoori.web.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.mechoori.web.entity.Restaurant;

@Service
public class RestaurantServiceImp implements RestaurantService{

	@Override
	public List<Restaurant> getList() {
		
		List<Restaurant> list = new ArrayList<>();
		
		
	return list;
	}

}
