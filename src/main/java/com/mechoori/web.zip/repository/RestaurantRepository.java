package com.mechoori.web.repository;

public interface RestaurantRepository {

}
